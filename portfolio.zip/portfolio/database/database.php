<?php

    $con = new PDO("mysql:host=localhost;dbname=s_567589_db1", "s_567589", "EefbD");
    $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
?>